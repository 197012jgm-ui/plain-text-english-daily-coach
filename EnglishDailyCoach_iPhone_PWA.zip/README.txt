# English Daily Coach — iPhone PWA

## 文件
- index.html：主应用
- manifest.json：手机 App 配置
- sw.js：离线缓存
- icon-192.png / icon-512.png：App 图标

## 在 iPhone 上使用
1. 将整个文件夹部署到一个 HTTPS 网站（例如你的个人网站或静态网站托管）。
2. 用 iPhone Safari 打开网站。
3. 点 Safari 的“分享”按钮。
4. 选择“添加到主屏幕”。
5. 点击主屏幕上的 English Coach 图标即可像独立 App 一样运行。
6. 首次使用时允许麦克风和通知权限。

## 重要说明
- PWA 的 Service Worker 和通知功能要求 HTTPS（localhost 开发环境除外）。
- 当前版本的晨间提醒依赖浏览器/系统通知权限；网页不能保证在 iOS 上像原生闹钟一样强制唤醒 App。
- 语音识别能力取决于 iOS/Safari 版本。
